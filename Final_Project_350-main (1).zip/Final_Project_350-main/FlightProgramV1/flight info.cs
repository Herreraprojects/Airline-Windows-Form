﻿/*using System;

public class Class1
{
    int seats[] = new int[] { 5, 10, 15, 25, 30, 100, 17, 12, 30, 2 };
    public Class1()

	{
	}
}





public class JoelFinalarrays
{
    String[] destination = new String[] { "Dallas,TX", "Los Angeles, CA", "Cincinnati, OH", "Jacksonville, FL", "Las Vegas, Nevada", "Phoniex, Arizona" };
    int seats[] = new int[] { 5, 10, 15, 25, 30, 100, 17, 12, 30, 2 };
    int Standard = 100;
    int FirstClass = 250;

    ///show destinations
    public void destinations()
    {
        for (String d: destination)
        {
            System.out.println(d);

        }
    }



    ///check if desire location available
    public String check(String p)
    {
        String checkvalue = p;
        for (String d: destination)
        {
            ///compares choice to destinations data bank
            if (d.equals(checkvalue))
            {
                try
                {
                    return d;

                }
                catch (Exception e)
                {
                    System.out.println("Requested destination not available please try again");

                }

            }

        }
        return checkvalue;


    }

    ///see available flights and seats 
    public void flights()
    {


        System.out.println("Available seats: ");
        int i;
        for (i = 1; i < 5; i++)
        {
            System.out.println("Flight" + " " + "#" + ((int)(Math.random() * (200 - 100 + 1) + 100)) + " " + seats[new Random().nextInt(seats.length)] + " " + "seats");
        }

    }
*/