﻿using System.Configuration;
using System.Net.Http;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace FlightProgramV1
{
    internal class Flight_Data
    {
        //Making our Flight Data variables
        private string FlightNumber = " ";
        private string FlightName = " ";
        private float SeatPrice = 0;

        public string AirlineNumber
        {
            get { return FlightNumber; }
            set
            {
                //A regular expression was thrown in to check that the beginning of the flight must have exactly 2 letters
                var mustHaveTwoLetters = Regex.IsMatch(value, @"^[A-Z]{2}$");

                if (string.IsNullOrEmpty(value) || !char.IsLetter(value[0]) || !mustHaveTwoLetters || FlightNumber.Length != 6)
                {
                    throw new InvalidFlightException("Flight number must start with two letters");
                }
                else
                {
                    FlightNumber = value;
                }
            }
        }
        public string AirlineName
        {
            get { return FlightName; }
            set
            {
                //Check and sees if there is no empty string and also makes sure that only letters are being entered
                if (string.IsNullOrEmpty(value) || !char.IsLetter(value[0]))
                {
                    throw new InvalidFlightException("Please enter a valid Flight Name");
                }
                else
                {
                    FlightName = value;
                }
            }
        }
        public float? AirlinePrice
        {
            get { return SeatPrice; }
            set
            {
                if (AirlinePrice == null)
                {
                    throw new InvalidFlightException("Please enter a valid Flight Price");
                }
                else
                {
                    AirlinePrice = value;
                }
            }
        }
    }
}

