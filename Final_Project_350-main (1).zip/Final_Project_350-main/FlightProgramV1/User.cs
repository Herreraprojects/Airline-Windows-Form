﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightProgramV1
{
    internal class User : Person
    {
        // -basic class for our users, which adds a username field onto the Person class-
        private string userName = "";
        public User() { }
        public User(string userName) :base() { this.userName = userName; }
        public string UserName { get { return userName; } set { userName = value; } }
    }
}
