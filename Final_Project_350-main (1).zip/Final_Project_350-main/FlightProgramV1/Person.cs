﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace FlightProgramV1
{
internal class Person
    {
        //Creating person fields 
        private string firstName;
        private string lastName;
        private string address;
        private int phone;

        //base constructor
        public Person() { }

        //Passing validation through our strings and making them public
        public string FirstName
        {
            get { return firstName; }
            set 
            {
                for (int i = 0; i < value.Length; i++)
                {
                    if (!Char.IsLetter(value[i]))
                    {
                        throw new InvalidNameException("Name must contain only Characters");
                    }
                }
                firstName = value; 
            }
        }
        public string LastName
        {
            get { return lastName; }
            set
            {
                for (int i = 0; i < value.Length; i++)
                {
                    if (!Char.IsLetter(value[i]))
                    {
                        throw new InvalidNameException($"{value[i]} Name must contain only Characters");
                    }
                }
                lastName = value;
            }
        }

        //checking that the phone number reaches the required length. 
        public int Phone
        {
            get { return phone; }
            set 
            {
                
                if (value.ToString().Length != 10)
                {
                    phone = value;
                }
                else
                {
                    MessageBox.Show("Please enter a valid Phone number");
                }
            }
        }
    }
}
