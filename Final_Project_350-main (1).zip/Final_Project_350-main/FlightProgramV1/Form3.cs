﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
//check reservation page
namespace FlightProgramV1
{
    public partial class Form3 : Form
    {
        //data for flights
        string[] myMessages = { "Flight #123 --> 7 seats avaialable" , "Flight #456 --> 12 seats avaialable", "Flight #432 --> 4 seats avaialable", "Flight #789 --> 7 seats avaialable", "Flight #111 --> 1 seats avaialable", "Flight #222 --> 4 seats avaialable", "Flight #333 --> 23 seats avaialable", "Flight#444 --> 7 seats avaialable", "Flight#555 --> 9 seats avaialable", "Flight #888 --> 5 seats avaialable" };
        string currentAccount;
        public Form3()
        {
            InitializeComponent();
        }
        public Form3(string currentUser)
        {
            InitializeComponent();
            currentAccount = currentUser;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        //switches window
        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            Form4 form4 = new Form4(currentAccount);
            form4.Show();
        }
        //prints out data in multiline
        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < myMessages.Length; i++)
            {
                flightdata.AppendText(myMessages[i] + Environment.NewLine);
            }
        }
    }
}
