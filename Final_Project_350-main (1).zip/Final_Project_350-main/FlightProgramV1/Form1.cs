﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace FlightProgramV1
{
    public partial class Form1 : Form
    {
        private ArrayList usersList = new ArrayList();
        private ArrayList passwordsList = new ArrayList();
        private int currentUser = -1;
        public Form1()
        {
            InitializeComponent();
            this.BackgroundImage = Properties.Resources.bgImage;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            loginPanel.Location = new Point(
                this.ClientSize.Width / 2 - loginPanel.Size.Width / 2,
                this.ClientSize.Height / 2 - loginPanel.Size.Height / 2);
            loginPanel.Anchor = AnchorStyles.None;
            pictureBox1.Image = Properties.Resources.mapPhoto;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            try
            {
                // -load previous users and passwords to check for login-
                string inValue;
                bool user = true;
                if (File.Exists("users.txt"))
                {
                    using (StreamReader inFile = new StreamReader("users.txt"))
                    {
                        while ((inValue = inFile.ReadLine()) != null)
                        {
                            if (user)
                            {
                                usersList.Add(inValue);
                                user = false;
                            }
                            else
                            {
                                passwordsList.Add(inValue);
                                user = true;
                            }
                        }
                    }
                }
                else
                {
                    StreamWriter fil = new StreamWriter("users.txt");
                }
            }
            catch (FileNotFoundException ex)
            {
                lblErrorMessage.Text = ex.Message;
            }
            catch (Exception ex)
            {
                lblErrorMessage.Text = ex.Message;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblWelcomeMessage_Click(object sender, EventArgs e)
        {

        }

        private void txtPassWord_TextChanged(object sender, EventArgs e)
        {
            txtPassWord.PasswordChar = '*';
        }

        private void loginPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        { 
            // -file IO and Error handling for logging users in-
            try
            {
                // -Write the user into the passwords file if they aren't found in the userlist-
                string inValue;
                bool user = true;
                if (btnLogin.Text == "&Sign up")
                {
                    using (StreamWriter inFile = new StreamWriter("users.txt"))
                    {
                        inFile.WriteLine(txtUserName.Text);
                        inFile.WriteLine(txtPassWord.Text);
                    }
                    Form2 form2 = new Form2(txtUserName.Text);
                    this.Hide();
                    form2.ShowDialog();
                }
                else
                {
                    if (txtPassWord.Text == passwordsList[currentUser].ToString())
                    {
                        Form2 form2 = new Form2(usersList[currentUser].ToString());
                        this.Hide();
                        form2.ShowDialog();
                    }
                    else
                    {
                        lblErrorMessage.Text = "Please re-enter password";
                    }
                }
            }
            catch (FileNotFoundException ex)
            {
                lblErrorMessage.Text = ex.Message;
            }
            catch (Exception ex)
            {
                lblErrorMessage.Text = ex.Message;
            }
        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {
            // -base the text of the login button on what the user enters-
            // -we'll have it change to sign up if the name isn't recognized-
            if (usersList.Contains(txtUserName.Text))
            {
                btnLogin.Text = "&Login";
                currentUser = usersList.IndexOf(txtUserName.Text);
            }
            else
            {
                if (txtUserName.TextLength > 0)
                {
                    btnLogin.Text = "&Sign up";
                }
                else
                {
                    btnLogin.Text = "&Login/Sign up";
                }
            }
        }
    }
}
