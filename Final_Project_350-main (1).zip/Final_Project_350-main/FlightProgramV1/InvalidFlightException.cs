﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightProgramV1
{
    internal class InvalidFlightException : SystemException
    {
        public InvalidFlightException(string mess) : base(mess) 
        { 
            
        }
    }
    internal class InvalidNumberException : SystemException
    {
        public InvalidNumberException(string mess) : base(mess)
        {
            
        }
    }
    internal class InvalidNameException : SystemException
    {
        public InvalidNameException(string mess) : base(mess)
        {
            
        }
    }
}
