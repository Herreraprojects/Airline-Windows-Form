﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightProgramV1
{
    public partial class Form5 : Form
    {
        string currentAccount;
        public Form5()
        {
            InitializeComponent();
        }
        public Form5(string currentUser)
        {
            InitializeComponent();
            currentAccount = currentUser;
        }

        //swithces window
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();

            Form2 form2 = new Form2(currentAccount);
            form2.Show();
        }
        ///prints out flight status message
        private void button1_Click(object sender, EventArgs e)
        {
            flightstatus.AppendText("Your flight is on time! Remeber to arrive to the airport 2 hours before your flight departs.");

        }

        private void flightstatus_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
