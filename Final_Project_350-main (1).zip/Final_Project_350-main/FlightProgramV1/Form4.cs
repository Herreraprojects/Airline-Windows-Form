﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//whos flying page
namespace FlightProgramV1
{
    public partial class Form4 : Form
    {
        string currentAccount;
        public Form4()
        {
            InitializeComponent();
        }
        public Form4(string currentUser)
        {
            InitializeComponent();
            currentAccount = currentUser;
        }

        //purchase button 
        private void button1_Click(object sender, EventArgs e)
        {
            //Validating our text fields
            Person person = new Person();
            string fName = txtFname.Text;
            if(fName.Any(char.IsDigit))
                try
                {
                    person.FirstName = fName;
                }
                catch (InvalidNameException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            string lName = txtlName.Text;
            if (fName.Any(char.IsDigit))
                try
                {
                    person.FirstName = fName;
                }
                catch (InvalidNameException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            string Email = txtEmail.Text;
            if(Email == null)
            {
                MessageBox.Show("Please enter something");
            }
            
            //Validating our Phone number 
            if (int.TryParse(txtPhone.Text, out int phone))
            {
                string vPhone = phone.ToString();
                if (vPhone.Length != 10)
                {
                    MessageBox.Show("Please enter a valid phone number");
                }
            }

            this.Hide();
            Form2 form2 = new Form2(currentAccount);
            form2.Show();
            MessageBox.Show("Reservation made. Thanks for choosing Flyo!");


        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}
