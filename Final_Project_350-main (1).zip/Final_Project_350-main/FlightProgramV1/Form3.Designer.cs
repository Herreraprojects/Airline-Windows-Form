﻿namespace FlightProgramV1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.flightdata = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rdTicketStandard = new System.Windows.Forms.RadioButton();
            this.rdTicketFirstClass = new System.Windows.Forms.RadioButton();
            this.flightNum = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Destination ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "From ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(288, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "To";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Bourbonnais, IL",
            "Chicago, IL",
            "Dallas, Texas",
            "Las Angeles, California",
            "Phoenix, Arizona",
            "Jacksonville, Florida",
            "Detriot, Michigan",
            "New York, New York",
            "Las Vegas, Nevada"});
            this.comboBox1.Location = new System.Drawing.Point(94, 70);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(169, 33);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Bourbonnais, IL",
            "Chicago, IL",
            "Dallas, Texas",
            "Las Angeles, California",
            "Phoenix, Arizona",
            "Jacksonville, Florida",
            "Detriot, Michigan",
            "New York, New York",
            "Las Vegas, Nevada"});
            this.comboBox2.Location = new System.Drawing.Point(332, 70);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(169, 33);
            this.comboBox2.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(520, 59);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 55);
            this.button1.TabIndex = 5;
            this.button1.Text = "SEARCH";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // flightdata
            // 
            this.flightdata.Location = new System.Drawing.Point(32, 130);
            this.flightdata.Multiline = true;
            this.flightdata.Name = "flightdata";
            this.flightdata.ReadOnly = true;
            this.flightdata.Size = new System.Drawing.Size(535, 377);
            this.flightdata.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(661, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(152, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "Flight Number ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(661, 253);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 25);
            this.label6.TabIndex = 9;
            this.label6.Text = "Ticket";
            // 
            // rdTicketStandard
            // 
            this.rdTicketStandard.AutoSize = true;
            this.rdTicketStandard.Location = new System.Drawing.Point(666, 295);
            this.rdTicketStandard.Name = "rdTicketStandard";
            this.rdTicketStandard.Size = new System.Drawing.Size(190, 29);
            this.rdTicketStandard.TabIndex = 10;
            this.rdTicketStandard.TabStop = true;
            this.rdTicketStandard.Text = "Standard: $100";
            this.rdTicketStandard.UseVisualStyleBackColor = true;
            // 
            // rdTicketFirstClass
            // 
            this.rdTicketFirstClass.AutoSize = true;
            this.rdTicketFirstClass.Location = new System.Drawing.Point(666, 329);
            this.rdTicketFirstClass.Name = "rdTicketFirstClass";
            this.rdTicketFirstClass.Size = new System.Drawing.Size(193, 29);
            this.rdTicketFirstClass.TabIndex = 11;
            this.rdTicketFirstClass.TabStop = true;
            this.rdTicketFirstClass.Text = "First Class: 300";
            this.rdTicketFirstClass.UseVisualStyleBackColor = true;
            // 
            // flightNum
            // 
            this.flightNum.Location = new System.Drawing.Point(666, 205);
            this.flightNum.Name = "flightNum";
            this.flightNum.Size = new System.Drawing.Size(146, 31);
            this.flightNum.TabIndex = 12;
            //this.flightNum.TextChanged += new System.EventHandler(this.flightNum_TextChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(601, 437);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(310, 70);
            this.button2.TabIndex = 14;
            this.button2.Text = "Make Reservation";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(938, 566);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.flightNum);
            this.Controls.Add(this.rdTicketFirstClass);
            this.Controls.Add(this.rdTicketStandard);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.flightdata);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form3";
            this.Text = "Book Flight";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox flightdata;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton rdTicketStandard;
        private System.Windows.Forms.RadioButton rdTicketFirstClass;
        private System.Windows.Forms.TextBox flightNum;
        private System.Windows.Forms.Button button2;
    }
}